#' Read the data
#'
#' It reads / loads the data of interest.
#' @param Counts_file character. The location of the normalised marker expression file (required). It should be a .txt file of a G x (N+1) data matrix of G markers (e.g. genes) and N samples (e.g. cells). Rownames are not needed. The first column of the matrix should be named 'Marker' and should contain the marker names (preferrable format is EnsemblID:nameID). The rest of the columns should be named with a unique sampleID for each sample and should contain the normalised expression values.
#' @param Design_file character. The location of the experimental design file (required). It should be a .txt file of a N x M data matrix where M is a number of sample characteristics measured for each of the N samples (e.g. library size, cell type, condition etc). Rownames are not needed. The table should ALWAYS contain the following column names: (1) 'SampleID' the unique sampleID for each sample (should match exactly the column names of the Counts file), (2) 'Condition' is the experimental conditions (e.g. Normal, Control, Disease etc), (3) 'CellType' describes one or more cell types used in the experiment (if not relevant, a constant value such as 'Bulk_Cells' can be used)  and (4) at least 2 of "Dim1", "Dim2" and "Dim3" giving the values of the dimensionality reduction components (e.g. PCA). Any number of other columns with sample information can be added.
#' @param DE_file character. The location of the file with the differential expression analysis results (optional). It should be a .txt file with the differential expression statistics for each marker as produced by t-test, wilcoxon test, limma, edgeR, DESeq2 or any other similar software. Rownames are not needed. The first column should be named as 'Marker' and should contain the marker IDs (preferably in the same format as those in the Counts file). Each ID may appear more than once if multiple comparisons have been done. Other columns that should ALWAYS be present are: (1) 'logFC' with the log fold changes, (2) 'logCMP' with the log average values for each marker over all samples, (3) 'PValue' with the estimated P-values, (4) 'FDR' with the FDRs, (5) 'Comparison' with he relevant comparison of two conditions or other separated with '-' to have a meaningful logFC interpretation (e.g. Normal-Disease) and (6) 'CellType' with the cell type of the comparison (it should partly match the CellType levels of the Design file). Any other column such as the value of the test statistic is permitted but it is optional.
#' @param Markers_file character. The location of the file with the marker names to be visualised. It should be a .txt file listing the marker IDs of interest (preferably in the same format as those of the Counts file). The contents of this file will be contrasted to the marker IDs of the Counts file to obtain the marker data for visualisation. If NULL (default) the user is prompted to key the marker ID of interest in the MarkerQuery().
#' @param is.Exact logical. If TRUE, the exact marker IDs of the Markers_file are retrieved from the Counts_file. Otherwise a pattern algorithm is used to return all pattern matching names. Default is TRUE.
#' @param logFC_cutoff numeric. A positive value specifying the logFC criterion of the differentially expressed genes of the DE_file. If the Markers_file is missing and the DE_file is present, the algorithm will retrieve the markers that satisfy the logFC and FDR criteria. Default is 0.
#' @param FDR_cutoff numeric. A value in (0,1] specifying the FDR criterion of the differentially expressed genes of the DE_file. If the Markers_file is missing and the DE_file is present, the algorithm will retrieve the markers that satisfy the logFC and FDR criteria. Default is 1.
#' @keywords readData
#' @return data list. A list with the 'Counts' data, the 'Design' data, the 'Annotation' data (marker IDs), the 'DEstats' data (differential expression results), the 'Output_Folder' where the final results (plots and tables) will be stored, the 'Dimensions' to be plotted, the 'Exact_Marker_Match' specifying the marker finding pattern, the 'logFC' and 'FDR' cutoffs and a sublist 'filteredData' containing only the data of the markers of interest for visualisation. Slot filteredData contains an extra component with the marker IDs to be visualised (filteredData$Marker_List). If both the DE_file and the Markers_files are missing then Marker_List contains all the marker names of the Counts_file.
#' @export
#' @examples
#' data<-readData(Counts_file=system.file("extdata", "CorrCounts.txt", package = "nMyo"),
#'          Design_file=system.file("extdata", "design_table.txt", package = "nMyo"),
#'          DE_file=system.file("extdata", "DE.txt", package = "nMyo"))
#'
readData<-function(Counts_file,Design_file,DE_file,Markers_file=NULL,is.Exact=TRUE,logFC_cutoff=0,FDR_cutoff=1){

    # stopping rule if the names are not correct or the required files do not exist
    fs<-firstStop(Counts_file=Counts_file,Design_file=Design_file)

    # read the required data: counts, design; Fix the annotation; Read the optional data: DE, Markers
    data<-RequiredDataReader(Counts_file=Counts_file,Design_file=Design_file)
    data<-testDataValidity(Data=data,DE_file=DE_file)
    genes<-ReadMarkers(Markers_file=Markers_file)
    if(!is.null(genes)){
        data<-c(data,list(Status="Marker file",Exact_Marker_Match=is.Exact,logFC=logFC_cutoff,FDR=FDR_cutoff))
    } else {
        data<-c(data,list(Status="DE file",Exact_Marker_Match=is.Exact,logFC=logFC_cutoff,FDR=FDR_cutoff))
    }

    # find the final gene list through a list of rules and existing files
    sigDE_genes_status<-finaliseMarkerList(data=data,genes=genes)

    # find existing PCA/tSNE/UMAP dimensions
    w<-which(colnames(data$Design)=="Dim1" | colnames(data$Design)=="Dim2" | colnames(data$Design)=="Dim3")
    if(length(w)>0){
        dims<-cbind(colnames(data$Design)[w],w)
    }

    # define the output folder
    folder<-unlist(strsplit(Counts_file,"/"))
    data_folder<-paste(paste(folder[1:(length(folder)-1)],collapse="/"),"/",sep="")
    output_folder<-paste(paste(folder[1:(length(folder)-1)],collapse="/"),"/Output/",sep="")
    if (!file.exists(output_folder)){
         dir.create(output_folder)
    }

    #summarise the data
    data<-c(data,list(Output_Folder=output_folder,Dimensions=dims))

    # summarise the filtered data
    redData<-fixFilteredData(data=data,sigDE.genes.status=sigDE_genes_status)

    res<-c(data,list(temp=redData,filteredData=redData))

    setDate<-unlist(strsplit(date()," ",fixed=T))
    setDate<-setDate[c(1,2,3,5,4)]
    setDate[5]<-chartr(old = ":", new = ".", setDate[5])
    setDate<-paste(setDate,collapse="_")
    res$filteredData$Design<-cbind(res$filteredData$Design,t(res$filteredData$Counts))
    res$Date_Stamp<-setDate

    return(res)
}
