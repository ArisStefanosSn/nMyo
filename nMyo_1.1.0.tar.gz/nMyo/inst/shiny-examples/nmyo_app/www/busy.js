setInterval(function(){
  if($('html').attr('class')=='shiny-busy'){
    $('div.busy').show()
  } else {
    $('div.busy').hide()
  }
},100)